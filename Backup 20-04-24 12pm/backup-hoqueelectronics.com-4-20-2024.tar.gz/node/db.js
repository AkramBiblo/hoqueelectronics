var mysql = require("mysql");
exports.con = mysql.createConnection({
  host: "premium180.web-hosting.com",
  user: "hoqunwoh_hoque_electronics",
  password: "$Hoque_123#",
  database: "hoqunwoh_hoque_electronics"
})

// con.connect(function(err) {
//     if (err) throw err;
//     console.log('Connected to your database.')
//   });
